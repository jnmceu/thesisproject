﻿using AppointmentSystemThesis.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;


namespace AppointmentSystemThesis.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        // DbSet for PatientModel
        public DbSet<PatientModel> Patients { get; set; }
    }

}
